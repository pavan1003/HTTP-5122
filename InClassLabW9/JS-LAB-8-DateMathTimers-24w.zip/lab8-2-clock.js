﻿/* LAB 8.2 - STOP TIME */


//create page load listener

//create page load function

	//create variables for required HTML elements
	
	//create time variable so all functions have access to it
	
	
	//CREATE FUNCTION THAT DISPLAYS THE TIME
	
	
	//CREATE FUNCTION TO START THE CLOCK.
	
	
	//CREATE FUNCTION TO STOP THE CLOCK
	
	
	// SET EVENT LISTENERS
