﻿//LAB 9-DATA STORAGE: INDEX PAGE
//window.onload

    //check for stored values
        //retrieve stored values

        //change welcome text to stored name

        //change BG colour to stored colour

        //  document.body.style.background = 


		
//#####============== DO THIS PART FIRST! ===============		
    //get the form and set submit listener
	
	

	//onsubmit Function
        
        //get values from form
		
		
		//console.log the form values

        
        //store values
        
        



    