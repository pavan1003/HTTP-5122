//LAB 10 - 1 FAQ PAGE

//Listen for window load the jQuery way



	//Inside of here is your jQuery/JavaScript


	//ADD CLICK EVENT TO <h2>
	
	
	
	
	
	
	//CHANGE <p> BACKGROUND ON HOVER






